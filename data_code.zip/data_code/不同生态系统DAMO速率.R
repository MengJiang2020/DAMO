library(dplyr)
library(lme4)
library(MuMIn)
library(readr)
library(multcomp)
#library(sjPlot)
library(nlme)
library(car)
library(ggplot2)
library(ggforce)
library(ggpubr)
library(GGally)
library(ggsignif)
library(scales)
library(patchwork)
library(gghalves)
library(spdep)
library(emmeans)
library(dplyr)
library(multcomp)
library(quantreg)


############################全球Nitrate-AOM和Nitrite-AOM水平
#multi  <- read.csv("DAMO_multi.csv")
# Nitrate_AOM
#Nitrate_AOM <- multi$naDAMO_25  

multi  <- read.csv("data.csv")
Nitrate_AOM <- multi$Nitrate_AOM


# 计算非空值的统计量
mean_value <- mean(Nitrate_AOM, na.rm = TRUE)   # 均值
sd_value <- sd(Nitrate_AOM, na.rm = TRUE)      # 标准差 (SD)
n <- sum(!is.na(Nitrate_AOM))                  # 非空值的数量
se_value <- sd_value / sqrt(n)                # 标准误差 (SE)
median_value <- median(Nitrate_AOM, na.rm = TRUE) # 中位数
q1 <- quantile(Nitrate_AOM, probs = 0.25, na.rm = TRUE)  # 下四分位数 Q1
q3 <- quantile(Nitrate_AOM, probs = 0.75, na.rm = TRUE)  # 上四分位数 Q3
max_value <- max(Nitrate_AOM, na.rm = TRUE)  # 最大值
min_value <- min(Nitrate_AOM, na.rm = TRUE)  # 最小值


# 打印结果
cat("Mean:", mean_value, "\n")
cat("SD:", sd_value, "\n")
cat("SE:", se_value, "\n")
cat("Median:", median_value, "\n")
cat("Q1 (25th percentile):", q1, "\n")
cat("Q3 (75th percentile):", q3, "\n")
cat("Max value:", max_value, "\n")
cat("Min value:", min_value, "\n")

# Nitrite_AOM
#Nitrite_AOM <- multi$niDAMO_25  
Nitrite_AOM <- multi$Nitrite_AOM



# 计算非空值的统计量
mean_value <- mean(Nitrite_AOM, na.rm = TRUE)   # 均值
sd_value <- sd(Nitrite_AOM, na.rm = TRUE)      # 标准差 (SD)
n <- sum(!is.na(Nitrite_AOM))                  # 非空值的数量
se_value <- sd_value / sqrt(n)                # 标准误差 (SE)
median_value <- median(Nitrite_AOM, na.rm = TRUE) # 中位数
q1 <- quantile(Nitrite_AOM, probs = 0.25, na.rm = TRUE)  # 下四分位数 Q1
q3 <- quantile(Nitrite_AOM, probs = 0.75, na.rm = TRUE)  # 上四分位数 Q3
max_value <- max(Nitrite_AOM, na.rm = TRUE)  # 最大值
min_value <- min(Nitrite_AOM, na.rm = TRUE)  # 最小值

# 打印结果
cat("Mean:", mean_value, "\n")
cat("SD:", sd_value, "\n")
cat("SE:", se_value, "\n")
cat("Median:", median_value, "\n")
cat("Q1 (25th percentile):", q1, "\n")
cat("Q3 (75th percentile):", q3, "\n")
cat("Max value:", max_value, "\n")
cat("Min value:", min_value, "\n")


#############################不同生态系统AMO水平

#测试考虑随机效应、空间自相关
multi  <- read.csv("DAMO_multi.csv")

multi1 <- dplyr::select(multi, reference, Ecotype, Long,	Lati, y1) %>%
  filter(!is.na(Long)&!is.na(Lati)&!is.na(y1))%>%
  filter(!is.na(Ecotype) & Ecotype != "")


#测试空间自相关
ggplot(multi1, aes(x = Long, y = Lati, color = y1)) +
  geom_point() +
  labs(title = "Spatial Distribution of naDAMO")

# 创建空间邻近对象
coords <- multi1[, c("Long", "Lati")]

# 计算距离矩阵
dist <- as.matrix(dist(coords))

# 创建空间邻近对象
nb <- dnearneigh(coords, 0, 4000, longlat = TRUE)  # 根据数据设置适当的距离阈值
listw <- nb2listw(nb, style = "W")  # 创建空间权重矩阵
# 计算Moran's I
moran_result <- moran.test(multi1$y1, listw)
print(moran_result)    

#考虑空间自相关
set.seed(123)  # 设置随机种子以确保可重复性
multi1$Lati <- multi1$Lati + runif(nrow(multi1), min=-1e-5, max=1e-5)
multi1$Long <- multi1$Long + runif(nrow(multi1), min=-1e-5, max=1e-5)

head(multi1)
table(multi1$Ecotype)

mt2<-lme(y1~Ecotype,
         random = ~1|reference,
         correlation = corExp(form = ~ Lati + Long|reference),
         data=multi1,
         method="REML")
summary(mt2)



###########置信区间绘图
### 采用Bonferroni adjustment对P值进行校正
emmeans(mt2, pairwise~ Ecotype)

emm <- emmeans(mt2, "Ecotype", infer = c(TRUE, TRUE))  # 计算均值和置信区间
#将 emmeans 结果转换为一个可以用于 ggplot2 的数据框
emm_df <- summary(emm)
emm_df <- as.data.frame(emm_df)


summary1<-multi1 %>%
  group_by(Ecotype) %>%
  dplyr::summarise(sdy=sd(y1,na.rm=TRUE), y1=mean(y1))
# summarises the invasion data at the different levels of resident number

colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

# Define a base theme for all plots
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # 去除主要格栅线
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


### 依据原始数据（而非模型估计值）对分类变量结果作图a, b
# 转换为有序因子，并定义水平顺序
multi1 <- multi1 %>%
  mutate(Ecotype = factor(Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland")))

A <- ggplot(multi1,aes(x=Ecotype,y=y1))+
  geom_sina(aes(color=Ecotype),position="identity",
            size = 4,alpha=0.6,maxwidth=0.4,seed=12345,scale="width")+
  geom_boxplot(outlier.shape = NA,alpha=0.1,width=0.7,lwd=0.4)+
  scale_color_manual(values=c("#FF7F00", "#08519C", "#00bdcd", "#8859A8", "#006D2C"))+
  #geom_hline(yintercept = 1,lty=2)+
  geom_point(data=summary1,aes(x=Ecotype,y=y1),
             pch=21,fill="firebrick",size=5.0)+
  geom_point(data=emm_df, aes(x=Ecotype, y=emmean), color="darkblue", size=4) +  # 添加模型预测的均值
  geom_errorbar(data=emm_df, aes(x=Ecotype, y=emmean, ymin=lower.CL, ymax=upper.CL), width=0.15, size=1, color="darkblue") +
  scale_y_continuous(limits=c(-0.3,6),breaks=seq(0,6,2),labels = label_number(accuracy = 0.1))+
  labs(y = expression(Nitrate-AOM~rate~"\n"~(ln~nmol~CO[2]~g^{-1}~day^{-1})),
       x=NULL, tag = "(a)")+
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(-0.06, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,15), "pt"),
        axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1))

A


######################################################################################## niDAMO
multi  <- read.csv("DAMO_multi.csv")
#测试考虑随机效应、空间自相关
multi2 <- dplyr::select(multi, reference, Ecotype, Long,	Lati, y2) %>%
  filter(!is.na(Long)&!is.na(Lati)&!is.na(y2))%>%
  filter(!is.na(Ecotype) & Ecotype != "")


#测试方差异质性
bartlett.test(y2 ~ Ecotype, data = multi2) 

mt1<-lme(y2 ~ Ecotype,
         weights=varIdent(form =~ 1|Ecotype),
         random = ~1|reference,
         data=multi2,
         method="REML")

#测试空间自相关
ggplot(multi2, aes(x = Long, y = Lati, color = y2)) +
  geom_point() +
  labs(title = "Spatial Distribution of niDAMO")

# 创建空间邻近对象
coords <- multi2[, c("Long", "Lati")]

# 计算距离矩阵
dist <- as.matrix(dist(coords))

# 创建空间邻近对象
nb <- dnearneigh(coords, 0, 7000, longlat = TRUE)  # 根据数据设置适当的距离阈值
listw <- nb2listw(nb, style = "W")  # 创建空间权重矩阵
# 计算Moran's I
moran_result <- moran.test(multi2$y2, listw)
print(moran_result)    


set.seed(123)  # 设置随机种子以确保可重复性
multi2$Lati <- multi2$Lati + runif(nrow(multi2), min=-1e-5, max=1e-5)
multi2$Long <- multi2$Long + runif(nrow(multi2), min=-1e-5, max=1e-5)


mt2<-lme(y2 ~ Ecotype,
         weights=varIdent(form =~ 1|Ecotype),
         random = ~1|reference,
         correlation = corExp(form = ~ Lati + Long|reference),
         data=multi2,
         method="REML")
AIC(mt2)

summary(mt2)

###########置信区间绘图
emmeans(mt2, "Ecotype")
### 采用Bonferroni adjustment对P值进行校正
emmeans(mt2, pairwise ~ Ecotype)

emm <- emmeans(mt2, "Ecotype", infer = c(TRUE, TRUE))  # 计算均值和置信区间
#将 emmeans 结果转换为一个可以用于 ggplot2 的数据框
emm_df <- summary(emm)
emm_df <- as.data.frame(emm_df)

summary2<-multi2 %>%
  group_by(Ecotype) %>%
  dplyr::summarise(sdy=sd(y2,na.rm=TRUE), y2=mean(y2))

### 依据原始数据（而非模型估计值）对分类变量结果作图a, b

# Define a base theme for all plots
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # 去除主要格栅线
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


### 依据原始数据（而非模型估计值）对分类变量结果作图a, b
multi2 <- multi2 %>%
  mutate(Ecotype = factor(Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland")))

x_offset <- 0.5 
B <- ggplot(multi2,aes(x=Ecotype,y=y2))+
  geom_sina(aes(color = Ecotype),  # 将颜色映射到边框
            shape = 21,            # 可填充的点形状（默认圆形）
            fill = NA,             # 无填充颜色
            position = "identity",
            size = 3, 
            alpha = 0.6,
            maxwidth = 0.4,
            seed = 12345,
            scale = "width",
            stroke = 1.5 )+
  geom_boxplot(outlier.shape = NA,alpha=0.1,width=0.7,lwd=0.4)+
  scale_color_manual(values=c("#FF7F00", "#08519C", "#00bdcd", "#8859A8", "#006D2C","#9ec417"))+
  #geom_hline(yintercept = 1,lty=2)+
  geom_point(data=summary2,aes(x=Ecotype,y=y2),
             pch=21,fill="firebrick",size=5.0)+
  geom_point(data=emm_df, aes(x=Ecotype, y=emmean), color="darkblue", size=3) +  # 添加模型预测的均值
  geom_errorbar(data=emm_df, aes(x=Ecotype, y=emmean, ymin=lower.CL, ymax=upper.CL), width=0.15, size=1, color="darkblue") +
  scale_y_continuous(limits=c(-0.3,6),breaks=seq(0,6,2),labels = label_number(accuracy = 0.1))+
  labs(y = expression(Nitrite-AOM~rate~"\n"~(ln~nmol~CO[2]~g^{-1}~day^{-1})),
       x=NULL, tag = "(b)")+
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(-0.06, 0.98),
        plot.margin = unit(c(5.5,5.5,5.5,15), "pt"),
        axis.text.x = element_text(angle = 30, hjust = 1, vjust = 1))

B

Figure2 <- A + B + plot_layout(ncol=2,nrow=1)

ggsave("Figure2_1.pdf", Figure2, device="pdf", scale=1, width=180, height=120, units="mm",dpi=500)

