
  #### #### #### #### #### #### #### #### #### #### #### #### #### #### #### #### 20210604
  
  library(readxl)       # To read Excel files
  library(dplyr)        # For data manipulation
  library(ggplot2)      # For creating plots
  library(maps)         # For world map data
  
  # 读取数据
   data_map <- read_excel("map.xlsx")
  World <- map_data("world")
  World <- World[World$region != "Antarctica", ]
 #########以生态系统类型划分    
  # 汇总数据准备绘制图形
  Geolocation2 <- data_map %>%
    group_by(Long, Lati, Ecotype2) %>%
    summarize(Samplesize = n(), .groups = 'drop')  # 完成分组后删除组信息
  
    # 创建地图图形
  #data_map <- data_map %>%
  # mutate(Ecotype = factor(Ecotype, levels = c("1Paddy", "2Tidal zone", "3Inland wetland", "4Estuary", "5Forest & Grassland", "6Forest & Grassland")))
  
  mp2 <- ggplot() +
    geom_polygon(data = World, aes(x = long, y = lat, group = group), fill = "white", color = "#333333", size = 0.3) +
    geom_point(data = Geolocation2, aes(x = Long, y =  Lati, color = Ecotype2), size = 2.5,  shape = 21, stroke = 1.8, alpha = 0.9) +
    scale_color_manual(values = c("#FF7F00", "#08519C", "#00bdcd", "#8859A8", "#006D2C","#808080"),
                       name = "Ecosystems", 
                       labels = c("1Paddy (268)", "2Tidal zone (238)", "3Inland wetland (226)", "4Estuary (149)",
                                  "5Forest & Grassland (143)", "6Others (8)")
                       ) +
    theme_minimal() +  # 使用一个基本的主题
    theme(plot.margin = margin(t = 10, r = 20, b = 10, l = 10, unit = "mm"))+
    guides(
      color = guide_legend(order = 1, override.aes = list(size = 5)),  # "Ecosystem Type" 图例显示在上面
      size = guide_legend(order = 2)  # "Sample Size" 图例显示在下面
    )+
    #scale_size_continuous(range = c(1, 10)) + # 调整圆圈大小范围
    theme_void() +
    labs(x = NULL, y = NULL) +
    scale_x_continuous(
      breaks = seq(-180, 180, by = 60),
      labels = function(x) ifelse(x < 0, paste(-x, "º W"), ifelse(x > 0, paste(x, "º E"), "0º"))
    ) +
    scale_y_continuous(
      breaks = seq(-90, 90, by = 30),
      labels = function(y) ifelse(y < 0, paste(-y, "º S"), ifelse(y > 0, paste(y, "º N"), "0º"))
    ) +
    guides(color = guide_legend(override.aes = list(size = 5))) +
    geom_hline(yintercept = c(-60, -30, 0, 30, 60), color = "gray", linetype = "dashed") +
    geom_vline(xintercept = c(-120, -60, 0, 60, 120), color = "gray", linetype = "dashed") +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14, face = "bold", color = "black"),
      panel.border = element_rect(colour = "black", fill = NA, size = 1),  # 添加边框
      axis.text = element_text(size = 12),
      legend.position = c(0.4, 0.02),
      legend.justification = c(1, 0),
      plot.margin = unit(c(5.5,5.5,5.5,15), "pt"),
      legend.title = element_text(size = 12, face = "bold"), # 自定义图例标题的字体大小
      legend.text = element_text(size = 12) # 自定义图例中字体的大小
    )  
  
  # 输出图形
  print(mp2) 
  ggsave("Figure1.pdf", mp2, device="pdf", scale=1, width=180, height=130, units="mm",dpi=300)
  