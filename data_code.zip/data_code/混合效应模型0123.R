library(MuMIn)
library(effects)
library(cowplot)
library(visreg)
library(glmmTMB)
library(car)
library(nlme)
library(emmeans)
library(ggplot2)
library(scales)
library(dplyr)
library(readr)
library(patchwork)
library(readr)
library(spdep)
library(kableExtra)
library(glmm.hp)


model_data0 <- read_csv("data.csv")

#log
model_data0 <- model_data0 %>% mutate(
  Nitrate_AOM = as.numeric(Nitrate_AOM),
  Nitrite_AOM = as.numeric(Nitrite_AOM),
  reference= as.character(reference),
  Ecotype = as.character(Ecotype),
  Long = as.numeric(Long),
  Lati = as.numeric(Lati),
  Tem = as.numeric(Tem),
  MMP = as.numeric(MMP),
  Depth = as.numeric(Depth),
  pH = as.numeric(pH),
  Nitra = as.numeric(Nitra),
  Nitri = as.numeric(Nitri),
  Amm = as.numeric(Amm),
  pmoA = as.numeric(pmoA),
  mcrA = as.numeric(mcrA),
  Moist = as.numeric(Moist),
  Sali = as.numeric(Sali),
  ORP = as.numeric(ORP),
  Meth = as.numeric(Meth),
  Fe3 = as.numeric(Fe3),
  Fe2 = as.numeric(Fe2),
  Sulf = as.numeric(Sulf),
  TOC = as.numeric(TOC),
  TN = as.numeric(TN),
  Moxy = as.numeric(Moxy),
  Mnit = as.numeric(Mnit)
  
)

#log
model_data <- mutate(model_data0,Nitrate_AOM = log(Nitrate_AOM+1), Nitrite_AOM = log(Nitrite_AOM+1),Tem=log(Tem+10),
                     MMP=log(MMP+1), Depth=log(Depth+1),  pH=log(pH+1), Nitra = log(Nitra+1), Nitri = log(Nitri+1), 
                     Amm = log(Amm+1), pmoA = log(pmoA+1), mcrA = log(mcrA+1), Moist = log(Moist+1), Sali = log(Sali+1),
                     ORP = log(ORP+1),Meth = log(Meth+1), Fe3 = log(Fe3+1), Fe2 = log(Fe2+1), Sulf = log(Sulf+1),
                     TOC = log(TOC+1),TN = log(TN+1), Moxy = log(Moxy+1), Mnit = log(Mnit+1))


#########Nitrate_AOM, mcrA

###data
Me_na <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype, Long, Lati, Tem, MMP, Depth, pH, TOC, Nitra, Nitri, Amm, mcrA, pmoA)
#ȥ���Ļ���׼��
Me_na <- Me_na %>%
  mutate(across(.cols = where(is.numeric) & !all_of(c("Long", "Lati")), ~ scale(.) %>% as.vector))

Me_na <- dplyr::select(Me_na, reference, Nitrate_AOM, Ecotype, Long, Lati, Tem, MMP, Depth, pH, TOC, Nitra, Nitri, Amm, mcrA, pmoA) 

Me_na <- na.omit(Me_na)
names(Me_na)


#initial model
Nitrate_AOM_0 <- lm(Nitrate_AOM ~ Ecotype + Tem + MMP + Depth+ pH + TOC + Nitra + Nitri + Amm + mcrA + pmoA, data = Me_na)
                    
                      
vif(Nitrate_AOM_0)

#����������
bartlett.test(Nitrate_AOM ~ Ecotype, data = Me_na)


#���Կռ������
ggplot(Me_na, aes(x = Long, y = Lati, color = Nitrate_AOM)) +
  geom_point() +
  labs(title = "Spatial Distribution of Nitrate_AOM")

# �����ռ��ڽ�����
coords <- Me_na[, c("Long", "Lati")]

# ����������
dist <- as.matrix(dist(coords))

# �����ռ��ڽ�����
nb <- dnearneigh(coords, 0, 2000, longlat = TRUE)  # �������������ʵ��ľ�����ֵ
listw <- nb2listw(nb, style = "W")  # �����ռ�Ȩ�ؾ���
# ����Moran's I
moran_result <- moran.test(Me_na$Nitrate_AOM, listw)
print(moran_result)  



#���ǿռ������
set.seed(123) 
Me_na$Lati <- Me_na$Lati + runif(nrow(Me_na), min=-1e-5, max=1e-5)
Me_na$Long <- Me_na$Long + runif(nrow(Me_na), min=-1e-5, max=1e-5)

Nitrate_AOM1 <- lme(Nitrate_AOM ~ Tem + MMP + Depth+ pH + TOC + Nitra + Nitri + Amm + mcrA +pmoA+
                       Ecotype:Tem +  Ecotype:Depth+ Ecotype:pH + Ecotype:TOC + 
                       Ecotype:Amm + Ecotype:mcrA +Ecotype:pmoA + Nitra:TOC+ Nitri:TOC + Amm:TOC,
                      random = ~ 1 | reference,
                      control=lmeControl(maxIter= 10000, msMaxIter= 10000),
                     correlation = corExp(form = ~ Lati + Long|reference),
                      data = Me_na,
                      method="ML")


#######ģ�;���
na1 <- Nitrate_AOM1
Anova(na1)
### �ȴӲ������Ľ�����������
na1.1<-update(na1,~.-Amm:Ecotype)
Anova(na1.1)
na1.2<-update(na1.1,~.-MMP)
Anova(na1.2)
na1.3<-update(na1.2,~.-Depth)
Anova(na1.3)
na1.4<-update(na1.3,~.-Nitri)
Anova(na1.4)
na1.5<-update(na1.4,~.-mcrA:Ecotype)
Anova(na1.5)
na1.6<-update(na1.5,~.-TOC:Nitri)
Anova(na1.6)
na1.7<-update(na1.6,~.-TOC:Ecotype)
Anova(na1.7)
na1.8<-update(na1.7,~.-TOC:Nitra)
Anova(na1.8)

AIC(na1, na1.1, na1.2, na1.3, na1.4, na1.5, na1.6, na1.7, na1.8) # , na1.9, na1.10

print(na1.8)

### ģ�ͶԽ�������Ʊ�
as.data.frame(Anova(na1.8)) %>%
  kbl(caption = "Table 1: General determinants of Nitrate-AOM",digits=c(2,2,3),
      col.names= c( "Chisquare","df","P")) %>%
  kable_classic() %>%
  column_spec(1, bold = T)


na1.8 <- lme(Nitrate_AOM ~ Tem + pH + TOC + Nitra + Amm + mcrA + pmoA + Tem:Ecotype +
                Ecotype:Depth + pH:Ecotype + pmoA:Ecotype + TOC:Amm,  #
              random = ~ 1 | reference,
              control=lmeControl(maxIter= 1000000, msMaxIter= 1000000),
              correlation = corExp(form = ~ Lati + Long|reference),
              data = Me_na,
              method="REML")

AIC(na1.8)
Anova(na1.8)

r.squaredGLMM(na1.8)
summary(na1.8)
emmeans(na1.8, specs = pairwise ~ Ecotype)
glmm.hp(na1.8)







####################################################Nitrite_AOM
####################################################Nitrite_AOM
####################################################Nitrite_AOM

Me_ni <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype, Long, Lati,Tem, MMP, Depth, pH, TOC, Nitri, Amm, pmoA) 

#ȥ���Ļ���׼��
Me_ni <- Me_ni %>%
  mutate(across(.cols = where(is.numeric) & !all_of(c("Long", "Lati")), ~ scale(.) %>% as.vector))



Me_ni <- dplyr::select(Me_ni, reference, Nitrite_AOM, Ecotype, Long, Lati, Tem, MMP, Depth, pH, TOC,Nitri, Amm, pmoA) 

Me_ni <- na.omit(Me_ni)
names(Me_ni)

#initial model
Nitrite_AOM_0 <- lm(Nitrite_AOM ~ Ecotype + Tem + MMP + Depth+ pH + TOC + Nitri + Amm + pmoA, data = Me_ni)
vif(Nitrite_AOM_0)

#����������
bartlett.test(Nitrite_AOM ~ Ecotype, data = Me_ni)


#���Կռ������
ggplot(Me_ni, aes(x = Long, y = Lati, color = Nitrite_AOM)) +
  geom_point() +
  labs(title = "Spatial Distribution of Nitrite_AOM")

# �����ռ��ڽ�����
coords <- Me_ni[, c("Long", "Lati")]

# ����������
dist <- as.matrix(dist(coords))

# �����ռ��ڽ�����
nb <- dnearneigh(coords, 0, 9000, longlat = TRUE)  # �������������ʵ��ľ�����ֵ
listw <- nb2listw(nb, style = "W")  # �����ռ�Ȩ�ؾ���
# ����Moran's I
moran_result <- moran.test(Me_ni$Nitrite_AOM, listw)
print(moran_result)  



#���ǿռ������
set.seed(123) 
Me_ni$Lati <- Me_ni$Lati + runif(nrow(Me_ni), min=-1e-5, max=1e-5)
Me_ni$Long <- Me_ni$Long + runif(nrow(Me_ni), min=-1e-5, max=1e-5)


Nitrite_AOM1 <- lme(Nitrite_AOM ~ Tem + MMP + Depth+ pH + TOC +  Nitri + Amm + pmoA +
                       Ecotype:Tem + Ecotype:MMP + Ecotype:Depth+ Ecotype:pH +
                       Ecotype:Nitri + Ecotype:pmoA,
                       random = ~ 1 | reference,
                       weights = varIdent(form =~ 1 | Ecotype),
                       control=lmeControl(maxIter= 100000, msMaxIter= 100000),
                       correlation = corExp(form = ~ Lati + Long|reference),
                       data = Me_ni,
                       method="ML")

#######ģ�;���
ni1 <- Nitrite_AOM1
Anova(ni1)
AIC(ni1)
### �ȴӲ������Ľ�����������
ni1.1<-update(ni1,~.-MMP)
Anova(ni1.1)
AIC(ni1.1)
ni1.2<-update(ni1.1,~.-pH)
Anova(ni1.2)
AIC(ni1.2)
ni1.3<-update(ni1.2,~.-Depth:Ecotype)
Anova(ni1.3)
AIC(ni1.3)
ni1.4<-update(ni1.3,~.-Nitri)
Anova(ni1.4)
AIC(ni1.4)
ni1.5<-update(ni1.4,~.-TOC)
Anova(ni1.5)
AIC(ni1.5)
ni1.6<-update(ni1.5,~.-Amm)
Anova(ni1.6)
AIC(ni1.6)


AIC(ni1, ni1.1, ni1.2, ni1.3, ni1.4, ni1.5, ni1.6)
print(ni1.6)

### ģ�ͶԽ�������Ʊ�
as.data.frame(Anova(ni1.6)) %>%
  kbl(caption = "Table 1: General determinants of Nitrite_AOM",digits=c(2,2,3),
      col.names= c( "Chisquare","df","P")) %>%
  kable_classic() %>%
  column_spec(1, bold = T)

ni1.6 <- lme(Nitrite_AOM ~ Tem + Depth + TOC +  Tem:Ecotype + 
                Ecotype:pH + Nitri:Ecotype + Ecotype:Amm + pmoA:Ecotype,  
              weights = varIdent(form =~ 1 | Ecotype),
              random = ~ 1 | reference,
              control=lmeControl(maxIter= 10000, msMaxIter= 10000),
              correlation = corExp(form = ~ Lati + Long|reference),
              data = Me_ni,
              method="REML")
Anova(ni1.6)
AIC(ni1.6)

r.squaredGLMM(ni1.6)
summary(ni1.6)
emmeans(ni1.6, specs = pairwise ~ Ecotype)
glmm.hp(ni1.6)




