library(MuMIn)
library(effects)
library(cowplot)
library(visreg)
library(glmmTMB)
library(car)
library(nlme)
library(emmeans)
library(ggplot2)
library(scales)
library(dplyr)
library(readr)
library(patchwork)
library(readr)

model_data0 <- read_csv("data.csv")

head(model_data0)

model_data0 <- model_data0 %>% mutate(
  Nitrate_AOM = as.numeric(Nitrate_AOM),
  Nitrite_AOM = as.numeric(Nitrite_AOM),
  reference= as.character(reference),
  Ecotype = as.character(Ecotype),
  Long = as.numeric(Long),
  Lati = as.numeric(Lati),
  Tem = as.numeric(Tem),
  MMP = as.numeric(MMP),
  Depth = as.numeric(Depth),
  pH = as.numeric(pH),
  Nitra = as.numeric(Nitra),
  Nitri = as.numeric(Nitri),
  Amm = as.numeric(Amm),
  pmoA = as.numeric(pmoA),
  mcrA = as.numeric(mcrA),
  Moist = as.numeric(Moist),
  Sali = as.numeric(Sali),
  ORP = as.numeric(ORP),
  Meth = as.numeric(Meth),
  Fe3 = as.numeric(Fe3),
  Fe2 = as.numeric(Fe2),
  Sulf = as.numeric(Sulf),
  TOC = as.numeric(TOC),
  TN = as.numeric(TN),
  Moxy = as.numeric(Moxy),
  Mnit = as.numeric(Mnit)
  
)

#log
model_data <- mutate(model_data0,Nitrate_AOM = log(Nitrate_AOM+1), Nitrite_AOM = log(Nitrite_AOM+1), ratio =log(Nitrite_AOM+1)/log(Nitrate_AOM+1),  
                     Long=Long, Lati=Lati, Tem=log(Tem+10), MMP=log(MMP+1), 
                     Depth=log(Depth+1),  pH=log(pH+1), Nitra = log(Nitra+1), Nitri = log(Nitri+1), 
                     Amm = log(Amm+1),pmoA = log(pmoA+1), mcrA = log(mcrA+1), Moist = log(Moist+1), Sali = log(Sali+1),
                     ORP = log(ORP+1),Meth = log(Meth+1), Fe3 = log(Fe3+1), Fe2 = log(Fe2+1), Sulf = log(Sulf+1),
                     TOC = log(TOC+1),TN = log(TN+1), Moxy = log(Moxy+1), Mnit = log(Mnit+1))


#####################################################################################Tem
#data selection
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Tem)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)


mt<-lme(Nitrate_AOM~ Ecotype:Tem,
        random = ~1|reference,
       # weights=varIdent(form =~ 1|Ecotype),
       correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
anova(mt)
summary(mt)

AIC(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)

# group and predict
tem_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinTem = min(Tem),
    MaxTem = max(Tem)
  )

# new data
new_data_list <- lapply(1:nrow(tem_ranges), function(i) {
  expand.grid(
    Tem = seq(from = tem_ranges$MinTem[i], to = tem_ranges$MaxTem[i], length.out = 100),
    Ecotype = tem_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

# ggplot
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_Tem <- 
  ggplot(new_data, aes(x = Tem, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = paste("MMT (Ln", "\u2103", ")"), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(a)") +
  coord_cartesian(ylim=c(0,6))+
  scale_x_continuous(breaks = c(2.0, 2.6, 3.2, 3.8),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 2.0, y = 6, label = expression(italic(R^2*m) == 0.14 ~ ";" ~ italic(R^2*c) == 0.83), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=2.0, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98))   
na_Tem


############################################################ MMP�� Yes
#data selection
#data selection
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, MMP)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~ Ecotype:MMP,
        random = ~1|reference,
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
anova(mt)
summary(mt)

AIC(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)

# group and predict
tem_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinMMP = min(MMP),
    MaxMMP = max(MMP)
  )

# new data
new_data_list <- lapply(1:nrow(tem_ranges), function(i) {
  expand.grid(
    MMP = seq(from = tem_ranges$MinMMP[i], to = tem_ranges$MaxMMP[i], length.out = 100),
    Ecotype = tem_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

# ggplot
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_MMP <- 
  ggplot(new_data, aes(x = MMP, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "MMP (Ln mm)", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(b)") +
  coord_cartesian(ylim=c(0,6))+
  scale_x_continuous(breaks = c(1, 3, 5),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0.8, y = 6, label = expression(italic(R^2*m) == 0.13 ~ ";" ~ italic(R^2*c) == 0.77), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0.8, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))     
na_MMP

 

#####################################################################################Depth
#data selection
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Depth)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Depth,
        random = ~1|reference,
       # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
depth_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinDepth = min(Depth),
    MaxDepth = max(Depth)
  )

# new data
new_data_list <- lapply(1:nrow(depth_ranges), function(i) {
  expand.grid(
    Depth = seq(from = depth_ranges$MinDepth[i], to = depth_ranges$MaxDepth[i], length.out = 100),
    Ecotype = depth_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


# ����ˮƽ
significant_ecotypes <- c("Paddy")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_Depth <- 
  ggplot(new_data, aes(x = Depth, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Depth (Ln cm)", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(c)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0,7.5))+
  scale_x_continuous(breaks = c(0.5, 4, 7.5),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0.01, y = 6, label = expression(italic(R^2*m) == 0.17 ~ ";" ~ italic(R^2*c) == 0.80), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0.01, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Depth




#######################################################################pH

multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, pH)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)



mt<-lme(Nitrate_AOM~Ecotype:pH,
        random = ~1|reference,
       # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
ph_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(pH),
    MaxpH = max(pH)
  )

# new data
new_data_list <- lapply(1:nrow(ph_ranges), function(i) {
  expand.grid(
    pH = seq(from = ph_ranges$MinpH[i], to = ph_ranges$MaxpH[i], length.out = 100),
    Ecotype = ph_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
#significant_ecotypes <- c("Inland wetland", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)

na_pH <- 
  ggplot(new_data, aes(x = pH, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
 # geom_line(data = significant_data, size = 1.25) +
 # geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "pH  (Ln)", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(d)") +
  coord_cartesian(ylim=c(0,6), xlim=c(1.68,2.38))+
  scale_x_continuous(breaks = c(1.7, 2, 2.3),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 1.7, y = 6, label = expression(italic(R^2*m) == 0.17 ~ ";" ~ italic(R^2*c) == 0.80), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=1.7, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_pH



##################################################################TOC

multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, TOC)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))
#spatial autocorrelation

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:TOC,
        random = ~1|reference,
       # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
toc_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(TOC),
    MaxpH = max(TOC)
  )

# new data
new_data_list <- lapply(1:nrow(toc_ranges), function(i) {
  expand.grid(
    TOC = seq(from = toc_ranges$MinpH[i], to = toc_ranges$MaxpH[i], length.out = 100),
    Ecotype = toc_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy", "Tidal zone", "Estuary", "Forest & Grassland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)




na_TOC <- 
  ggplot(new_data, aes(x = TOC, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(TOC~(Ln~g~kg^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(e)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 5.2))+
  scale_x_continuous(breaks = c(0, 2.5, 5),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0, y = 6, label = expression(italic(R^2*m) == 0.29 ~ ";" ~ italic(R^2*c) == 0.88), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_TOC



###############################################################Nitrate
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Nitra)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Nitra,
        random = ~1|reference,
        #weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
nitra_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Nitra),
    MaxpH = max(Nitra)
  )

# new data
new_data_list <- lapply(1:nrow(nitra_ranges), function(i) {
  expand.grid(
    Nitra = seq(from = nitra_ranges$MinpH[i], to = nitra_ranges$MaxpH[i], length.out = 100),
    Ecotype = nitra_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy", "Forest & Grassland" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)

na_Nitra <- 
  ggplot(new_data, aes(x = Nitra, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(Nitrate~(Ln~mg~kg^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(f)") +
  coord_cartesian(ylim=c(0,6),xlim=c(0,3.3))+
  scale_x_continuous(breaks = c(0, 1.5, 3),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0, y = 6, label = expression(italic(R^2*m) == 0.14 ~ ";" ~ italic(R^2*c) == 0.80), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Nitra




############################################################################Nitri

multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype, Long, Lati, Nitri)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Nitri,
        random = ~1|reference,
        # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML",
        control = lmeControl(opt = "optim", msMaxIter = 1000))
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
Nitri_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Nitri),
    MaxpH = max(Nitri)
  )

# new data
new_data_list <- lapply(1:nrow(Nitri_ranges), function(i) {
  expand.grid(
    Nitri = seq(from = Nitri_ranges$MinpH[i], to = Nitri_ranges$MaxpH[i], length.out = 100),
    Ecotype = Nitri_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Forest & Grassland" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_Nitri <- 
  ggplot(new_data, aes(x = Nitri, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data=significant_data, size = 1.25) +
  geom_ribbon(data=significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Nitri, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(Nitrite~(Ln~mg~kg^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(g)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0,0.82))+
  scale_x_continuous(breaks = c(0, 0.4, 0.8),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.01, y = 6, label = expression(italic(R^2*m) == 0.14 ~ ";" ~ italic(R^2*c) == 0.54), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=-0.01, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"),
        axis.title.x = element_text(face = "italic"))   
na_Nitri










#####################################################################Amm
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Amm)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))


#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Amm,
        random = ~1|reference,
       weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
amm_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Amm),
    MaxpH = max(Amm)
  )

# new data
new_data_list <- lapply(1:nrow(amm_ranges), function(i) {
  expand.grid(
    Amm = seq(from = amm_ranges$MinpH[i], to = amm_ranges$MaxpH[i], length.out = 100),
    Ecotype = amm_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit

# no Ecotype

# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Forest & Grassland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_Amm <- 
  ggplot(new_data, aes(x = Amm, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data= significant_data, size = 1.25) +
  geom_ribbon(data= significant_data,aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(Ammonia~(Ln~mg~kg^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(h)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0,4.1))+
  scale_x_continuous(breaks = c(0, 2, 4),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.1, y = 6, label = expression(italic(R^2*m) == "0.20" ~ ";" ~ italic(R^2*c) == "0.67"), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=-0.1, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Amm










############################################################################mcrA

multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, mcrA)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:mcrA,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML",
        control = lmeControl(opt = "optim", msMaxIter = 1000))
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
mcrA_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(mcrA),
    MaxpH = max(mcrA)
  )

# new data
new_data_list <- lapply(1:nrow(mcrA_ranges), function(i) {
  expand.grid(
    mcrA = seq(from = mcrA_ranges$MinpH[i], to = mcrA_ranges$MaxpH[i], length.out = 100),
    Ecotype = mcrA_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_mcrA <- 
  ggplot(new_data, aes(x = mcrA, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data=significant_data, size = 1.25) +
  geom_ribbon(data=significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = mcrA, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(italic(mcrA)~(Ln~copies~g^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(i)") +
  coord_cartesian(ylim=c(0,6), xlim=c(7.5, 20))+
  scale_x_continuous(breaks = c(8, 14, 20),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 7.2, y = 6, label = expression(italic(R^2*m) == 0.35 ~ ";" ~ italic(R^2*c) == 0.72), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=7.2, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"),
        axis.title.x = element_text(face = "italic"))   
na_mcrA


############################################################################pmoA

multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype, Long, Lati, pmoA)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))


multi <- filter(multi, Ecotype != "Inland wetland")

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:pmoA,
        random = ~1|reference,
        # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML",
        control = lmeControl(opt = "optim", msMaxIter = 1000))
summary(mt)
anova(mt)
#emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
pmoA_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(pmoA),
    MaxpH = max(pmoA)
  )

# new data
new_data_list <- lapply(1:nrow(pmoA_ranges), function(i) {
  expand.grid(
    pmoA = seq(from = pmoA_ranges$MinpH[i], to = pmoA_ranges$MaxpH[i], length.out = 100),
    Ecotype = pmoA_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Estuary", "Forest & Grassland" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_pmoA <- 
  ggplot(new_data, aes(x = pmoA, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data=significant_data, size = 1.25) +
  geom_ribbon(data=significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = pmoA, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(italic(pmoA)~(Ln~copies~g^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(j)") +
  coord_cartesian(ylim=c(0,6), xlim=c(7, 20))+
  scale_x_continuous(breaks = c(8, 14, 20),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 7.2, y = 6, label = expression(italic(R^2*m) == 0.32 ~ ";" ~ italic(R^2*c) == 0.71), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=7.2, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"),
        axis.title.x = element_text(face = "italic"))   
na_pmoA





#########################################################Nitrite
#########################################################Nitrite
#########################################################Nitrite


#####################################################################################Tem
#data selection
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Tem)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~ Ecotype:Tem,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)

# group and predict
tem_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinTem = min(Tem),
    MaxTem = max(Tem)
  )

# new data
new_data_list <- lapply(1:nrow(tem_ranges), function(i) {
  expand.grid(
    Tem = seq(from = tem_ranges$MinTem[i], to = tem_ranges$MaxTem[i], length.out = 100),
    Ecotype = tem_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit




colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

# ggplot
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Tem <- 
  ggplot(new_data, aes(x = Tem, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data= significant_data, size = 1.25) +
  geom_ribbon(data= significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Tem, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = paste("MMT (Ln", "\u2103", ")"), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(k)") +
  coord_cartesian(ylim=c(0,6))+
  scale_x_continuous(breaks = c(2.5, 3.1, 3.7),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 2.5, y = 6, label = expression(italic(R^2*m) == 0.12 ~ ";" ~ italic(R^2*c) == 0.78), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=2.5, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Tem



############################################################ MMP�� Yes
#data selection
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, MMP)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~ Ecotype:MMP,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
mmp_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinMMP = min(MMP),
    MaxMMP = max(MMP)
  )

# new data
new_data_list <- lapply(1:nrow(mmp_ranges), function(i) {
  expand.grid(
    MMP = seq(from = mmp_ranges$MinMMP[i], to = mmp_ranges$MaxMMP[i], length.out = 100),
    Ecotype = mmp_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_MMP <- 
  ggplot(new_data, aes(x = MMP, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "MMP (Ln mm)", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(l)") +
  coord_cartesian(ylim=c(0,6))+
  scale_x_continuous(breaks = c(1, 3, 5),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0.8, y = 6, label = expression(italic(R^2*m) == 0.06 ~ ";" ~ italic(R^2*c) == 0.69), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0.8, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_MMP



#####################################################################################Depth
#data selection
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Depth)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:Depth,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")

summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
depth_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinDepth = min(Depth),
    MaxDepth = max(Depth)
  )

# new data
new_data_list <- lapply(1:nrow(depth_ranges), function(i) {
  expand.grid(
    Depth = seq(from = depth_ranges$MinDepth[i], to = depth_ranges$MaxDepth[i], length.out = 100),
    Ecotype = depth_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Inland wetland", "Forest & Grassland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Depth <- 
  ggplot(new_data, aes(x = Depth, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Depth (Ln cm)", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(m)") +
  coord_cartesian(ylim=c(0,6))+
  scale_x_continuous(breaks = c(0.2, 4.2, 8.2),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0.2, y = 6, label = expression(italic(R^2*m) == 0.04 ~ ";" ~ italic(R^2*c) == 0.66), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0.2, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Depth



#######################################################################pH

multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, pH)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:pH,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
ph_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(pH),
    MaxpH = max(pH)
  )

# new data
new_data_list <- lapply(1:nrow(ph_ranges), function(i) {
  expand.grid(
    pH = seq(from = ph_ranges$MinpH[i], to = ph_ranges$MaxpH[i], length.out = 100),
    Ecotype = ph_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Inland wetland", "Estuary" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_pH <- 
  ggplot(new_data, aes(x = pH, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data= significant_data, size = 1.25) +
  geom_ribbon(data= significant_data,aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
 # geom_line(data = ALLeff, aes(x = pH, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "pH (Ln)", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(n)") +
  coord_cartesian(ylim=c(0,6), xlim=c(1.5,2.35))+
  scale_x_continuous(breaks = c(1.5, 1.9, 2.3),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 1.5, y = 6, label = expression(italic(R^2*m) == 0.06 ~ ";" ~ italic(R^2*c) == 0.73), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=1.5, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_pH


##################################################################TOC
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, TOC)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:TOC,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
toc_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(TOC),
    MaxpH = max(TOC)
  )

# new data
new_data_list <- lapply(1:nrow(toc_ranges), function(i) {
  expand.grid(
    TOC = seq(from = toc_ranges$MinpH[i], to = toc_ranges$MaxpH[i], length.out = 100),
    Ecotype = toc_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_TOC <- 
  ggplot(new_data, aes(x = TOC, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(TOC~(Ln~g~kg^{-1})), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(o)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0.2, 6.6))+
  scale_x_continuous(breaks = c(0, 3.3, 6.6),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 0, y = 6, label = expression(italic(R^2*m) == 0.05 ~ ";" ~ italic(R^2*c) == 0.79), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=0, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   

ni_TOC



###############################################################Nitrite
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Nitri)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~ Ecotype:Nitri,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
nitri_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Nitri),
    MaxpH = max(Nitri)
  )

# new data
new_data_list <- lapply(1:nrow(nitri_ranges), function(i) {
  expand.grid(
    Nitri = seq(from = nitri_ranges$MinpH[i], to = nitri_ranges$MaxpH[i], length.out = 100),
    Ecotype = nitri_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


significant_ecotypes <- c("Paddy", "Tidal zone")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Nitri <- 
  ggplot(new_data, aes(x = Nitri, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = Nitrite~(Ln~mg~kg^{-1}), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(p)") +
  coord_cartesian(ylim=c(0,6),xlim=c(0,0.9))+
  scale_x_continuous(breaks = c(0, 0.4, 0.8),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  # annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.01, y = 6, label = expression(italic(R^2*m) == 0.01 ~ ";" ~ italic(R^2*c) == 0.76), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=-0.01, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Nitri




#####################################################################Amm
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Amm)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:Amm,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
AIC(mt)
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
amm_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Amm),
    MaxpH = max(Amm)
  )

# new data
new_data_list <- lapply(1:nrow(amm_ranges), function(i) {
  expand.grid(
    Amm = seq(from = amm_ranges$MinpH[i], to = amm_ranges$MaxpH[i], length.out = 100),
    Ecotype = amm_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Amm <- 
  ggplot(new_data, aes(x = Amm, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data= significant_data, size = 1.25) +
  geom_ribbon(data= significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = Ammonia~(Ln~mg~kg^{-1}), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(q)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0,4.1))+
  scale_x_continuous(breaks = c(0, 2, 4),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) + 
  annotate("text", x = -0.05, y = 6, label = expression(italic(R^2*m) == 0.08 ~ ";" ~ italic(R^2*c) == "0.80"), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=-0.05, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Amm



############################################################################pmoA

multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, pmoA)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~ Ecotype:pmoA,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML",
        control = lmeControl(opt = "optim", msMaxIter = 1000))
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
pmoA_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(pmoA),
    MaxpH = max(pmoA)
  )

# new data
new_data_list <- lapply(1:nrow(pmoA_ranges), function(i) {
  expand.grid(
    pmoA = seq(from = pmoA_ranges$MinpH[i], to = pmoA_ranges$MaxpH[i], length.out = 100),
    Ecotype = pmoA_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

# ����ˮƽ
significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland" )

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_pmoA <- 
  ggplot(new_data, aes(x = pmoA, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(italic(pmoA)~(Ln~copies~g^{-1})), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(r)") +
  coord_cartesian(ylim=c(0,6), xlim=c(5, 20))+
  scale_x_continuous(breaks = c(6, 13, 20),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 6, y = 6, label = expression(italic(R^2*m) == 0.12 ~ ";" ~ italic(R^2*c) == 0.77), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=6, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"),
        axis.title.x = element_text(face = "italic"))   
ni_pmoA




#######figure pachwork


multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))


# ����һ��ͨ�õ����⣬�������������
theme_hide_y <- theme(axis.title.y = element_blank(),
                      axis.text.y = element_blank(),
                      plot.tag.position = c(-0.08, 0.98), "pt")

na_Tem1 <- na_Tem
na_MMP1 <- na_MMP + theme_hide_y
na_Depth1 <- na_Depth + theme_hide_y
na_pH1 <- na_pH + theme_hide_y
na_TOC1 <- na_TOC + theme_hide_y


na_Nitra1 <- na_Nitra
na_Nitri1 <- na_Nitri + theme_hide_y
na_Amm1 <- na_Amm + theme_hide_y
na_mcrA1 <- na_mcrA + theme_hide_y
na_pmoA1 <- na_pmoA + theme_hide_y



###############################################ni-DAMO

ni_Tem1 <- ni_Tem
ni_MMP1 <- ni_MMP + theme_hide_y
ni_Depth1 <- ni_Depth + theme_hide_y
ni_pH1 <- ni_pH + theme_hide_y

ni_TOC1 <- ni_TOC
ni_Nitri1 <- ni_Nitri + theme_hide_y
ni_Amm1 <- ni_Amm + theme_hide_y
ni_pmoA1 <- ni_pmoA + theme_hide_y


Figure3 <-  na_Tem1  +  na_MMP1 +  na_Depth1 +  na_pH1 +  na_TOC1 +
             na_Nitra1 + na_Nitri1 + na_Amm1 + na_mcrA1 + na_pmoA1 +
             ni_Tem1  +  ni_MMP1 +  ni_Depth1 +  ni_pH1 +  ni_pH1 +
             ni_TOC1 + ni_Nitri1 + ni_Amm1 + ni_pmoA1 + ni_pmoA1 +
             plot_layout(ncol=5,nrow=4,guides = 'collect')
  
  
  
  
ggsave("Figure3.pdf", Figure3, device="pdf", scale=1, width=300, height=300, units="mm",dpi=300)




###############################����ͼ
library(Rmisc) # Ryan Miscellaneous
mean2 <- read.csv("A.csv")
#��ͼ
p2 <- ggplot(mean2, aes(sample,value, color = group)) + 
  geom_errorbar(aes(ymin = value- sd, ymax = value + sd), 
                width = 0,position = position_dodge(0.8),linewidth=0.5) + 
  geom_point(position = position_dodge(0.8),shape=18,size=3)+
  #ת��x����y��λ��
  coord_flip()+
  #y�᷶Χ����
  #scale_y_continuous(limits = c(30, 110))+
  #��������
  theme_bw()+
  theme(legend.position = c(1,0.85),
        legend.background = element_blank(),
        legend.key = element_blank(),
        panel.grid = element_blank(),
        axis.text.x = element_text(color = "black",size=10),
        axis.text.y = element_text(color = "black",size=10),
        axis.ticks.y = element_blank(),
        strip.background = element_rect(fill = "grey", color = "transparent"),
        strip.text = element_text(color="black",size=10))+
  #����λ��
  labs(y="Functional dispersion values",x=NULL,color=NULL)+
  scale_color_manual(values = c("#1965A9","#853B97"))+
  #���ӷ������
  #annotate("rect", xmin = 0, xmax = 6.5, ymin = -Inf, ymax = Inf, alpha = 0.2,fill="#d7ebce") +
  #annotate("rect", xmin = 6.5, xmax = 20.5, ymin = -Inf, ymax = Inf, alpha = 0.2,fill="#bcced6") +
  #annotate("rect", xmin = 20.5, xmax = 23, ymin = -Inf, ymax = Inf, alpha = 0.2,fill="#ffdc80")+
  #�ֶ����������Ա�ǣ�ͼ���г����֣�������ݸ������ݽ��е���
  #annotate('text', label = '**', x =11, y =80, angle=-90, size =5,color="black")+
  geom_segment(x = 10.5, xend = 11.5, y = 60, yend = 60,color = "black", size = 0.8)+
  facet_wrap(~ facet, nrow = 2, scales = "free_x")
# �ؼ��޸ģ�Ϊÿ����������3��x��̶�
p2
ggsave("A3.pdf", p2, device="pdf", scale=1, width=300, height=120, units="mm",dpi=300)











######################################################### Nitrate_AOM, Mnit
######################################################### Nitrate_AOM, Mnit
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Mnit)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~ Ecotype:Mnit,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML",
        control = lmeControl(opt = "optim", msMaxIter = 1000))
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
Mnit_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Mnit),
    MaxpH = max(Mnit)
  )

# new data
new_data_list <- lapply(1:nrow(Mnit_ranges), function(i) {
  expand.grid(
    Mnit = seq(from = Mnit_ranges$MinpH[i], to = Mnit_ranges$MaxpH[i], length.out = 100),
    Ecotype = Mnit_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


significant_ecotypes <- c("Paddy", "Inland wetland")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


na_Mnit <- 
  ggplot(new_data, aes(x = Mnit, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(italic(M.~nitroreducens)~(Ln~"16S rRNA"~copies~g^{-1})), y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(a)") +
  coord_cartesian(ylim=c(0,6), xlim=c(7, 18))+
  scale_x_continuous(breaks = c(8, 13, 18),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 7, y = 6, label = expression(italic(R^2*m) == 0.34 ~ ";" ~ italic(R^2*c) == 0.79), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.001"), x=7, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(-0.06, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,15), "pt"),
        axis.title.x = element_text(face = "italic"))   
na_Mnit








################################################## Nitrite_AOM, Moxy����������������������������������
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype, Long, Lati, Moxy)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#���Է���������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#���Կռ������
ggplot(multi, aes(x = Long, y = Lati, color = Nitrite_AOM)) +
  geom_point() +
  labs(title = "Spatial Distribution of Nitrate_AOM")

# �����ռ��ڽ�����
coords <- multi[, c("Long", "Lati")]
model_data0_clean <- na.omit(multi)
dist <- as.matrix(dist(coords))
nb <- dnearneigh(coords, 0, 1000, longlat = TRUE)  # �������������ʵ��ľ�����ֵ
weights <- nb2listw(nb, style = "W")


# ����Moran's I
moran_result <- moran.test(model_data0_clean$Nitrite_AOM, weights)
print(moran_result)   



#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM ~  Ecotype:Moxy,
        random = ~1|reference,
        #weights=varIdent(form =~ 1|Ecotype),
        #correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        control=lmeControl(maxIter= 100000000, msMaxIter= 100000000),
        method="REML")

print(mt)
summary(mt)
anova(mt)
r.squaredGLMM(mt)



# group and predict
Moxy_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Moxy),
    MaxpH = max(Moxy)
  )

# new data
new_data_list <- lapply(1:nrow(Moxy_ranges), function(i) {
  expand.grid(
    Moxy = seq(from = Moxy_ranges$MinpH[i], to = Moxy_ranges$MaxpH[i], length.out = 100),
    Ecotype = Moxy_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy", "Tidal zone", "Inland wetland", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Moxy <- 
  ggplot(new_data, aes(x = Moxy, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(italic(M.~oxyfera)~(Ln~"16S rRNA"~copies~g^{-1})), y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(b)") +
  coord_cartesian(ylim=c(0,6), xlim=c(6.5, 18.5))+
  scale_x_continuous(breaks = c(7, 12, 17),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = 6.5, y = 6, label = expression(italic(R^2*m) == 0.18 ~ ";" ~ italic(R^2*c) == 0.91), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=6.5, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(-0.06, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,15), "pt"),
        axis.title.x = element_text(face = "italic"))   
ni_Moxy


Figure3_bio <- na_Mnit + ni_Moxy + plot_layout(ncol=2,nrow=1,guides = 'collect')

ggsave("Figure 4S.pdf", Figure3_bio, device="pdf", scale=1, width=150, height=80, units="mm",dpi=300)








###########Supporting information

#####################################################################Moist
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Moist)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~ Ecotype:Moist,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
moist_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Moist),
    MaxpH = max(Moist)
  )

# new data
new_data_list <- lapply(1:nrow(moist_ranges), function(i) {
  expand.grid(
    Moist = seq(from = moist_ranges$MinpH[i], to = moist_ranges$MaxpH[i], length.out = 100),
    Ecotype = moist_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


na_Moist <- 
  ggplot(new_data, aes(x = Moist, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  #geom_line(size = 1.25) +
  #geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Moist, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Moisture", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(a)") +
  coord_cartesian(ylim=c(0,6), xlim=c(1.9,4.1))+
  scale_x_continuous(breaks = c(2, 3, 4.1),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  #annotate("text", x = 1.85, y = 6, label = expression(italic(R^2*m) == 0.06 ~ ";" ~ italic(R^2*c) == 0.79), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) > "0.05"), x=1.85, y=6, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Moist



########################################################################Fe3
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Fe3)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Fe3,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
fe3_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Fe3),
    MaxpH = max(Fe3)
  )

# new data
new_data_list <- lapply(1:nrow(fe3_ranges), function(i) {
  expand.grid(
    Fe3 = seq(from = fe3_ranges$MinpH[i], to = fe3_ranges$MaxpH[i], length.out = 100),
    Ecotype = fe3_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

na_Fe3 <- 
  ggplot(new_data, aes(x = Fe3, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  #geom_line(size = 1.25) +
  #geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Fe3, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Fe(III)", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(b)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 3.5))+
  scale_x_continuous(breaks = c(0, 1.6, 3.2),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  #annotate("text", x = -0.05, y = 6, label = expression(italic(R^2*m) == 0.27 ~ ";" ~ italic(R^2*c) == 0.96), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) > "0.05"), x=-0.05, y=6, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Fe3



##############################################################Fe(II)
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Fe2)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Fe2,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
fe2_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Fe2),
    MaxpH = max(Fe2)
  )

# new data
new_data_list <- lapply(1:nrow(fe2_ranges), function(i) {
  expand.grid(
    Fe2 = seq(from = fe2_ranges$MinpH[i], to = fe2_ranges$MaxpH[i], length.out = 100),
    Ecotype = fe2_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Tidal zone", "Inland wetland", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)




na_Fe2 <- 
  ggplot(new_data, aes(x = Fe2, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Fe2, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Fe(II)", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(c)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 2.4))+
  scale_x_continuous(breaks = c(0, 1.2, 2.4),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.05, y = 6, label = expression(italic(R^2*m) == 0.37 ~ ";" ~ italic(R^2*c) == 0.99), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.0001"), x=-0.05, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Fe2






######################################################################Salinity
######################################################################Salinity
multi <- dplyr::select(model_data, reference, Nitrate_AOM, Ecotype,Long, Lati, Sali)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrate_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrate_AOM~Ecotype:Sali,
        random = ~1|reference,
       # weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
sali_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Sali),
    MaxpH = max(Sali)
  )

# new data
new_data_list <- lapply(1:nrow(sali_ranges), function(i) {
  expand.grid(
    Sali = seq(from = sali_ranges$MinpH[i], to = sali_ranges$MaxpH[i], length.out = 100),
    Ecotype = sali_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

na_Sali <- 
  ggplot(new_data, aes(x = Sali, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrate_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  #geom_line(size = 1.25) +
  #geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Salinity", y = expression(Nitrate-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(e)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 3.3))+
  scale_x_continuous(breaks = c(0, 1.6, 3.2),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  #annotate("text", x = 0, y = 6, label = expression(italic(R^2*m) == 0.15 ~ ";" ~ italic(R^2*c) == 0.60), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) > "0.05"), x=0, y=6, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0.02, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
na_Sali




#####################################################################ni_______Moist
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Moist)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 


#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~  Ecotype:Moist,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        control = lmeControl(opt = "optim", msMaxIter = 1000, niterEM = 50, msVerbose = TRUE),
        method="REML")
summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
moist_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Moist),
    MaxpH = max(Moist)
  )

# new data
new_data_list <- lapply(1:nrow(moist_ranges), function(i) {
  expand.grid(
    Moist = seq(from = moist_ranges$MinpH[i], to = moist_ranges$MaxpH[i], length.out = 100),
    Ecotype = moist_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)



ni_Moist <- 
  ggplot(new_data, aes(x = Moist, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  #geom_line(data = significant_data, size = 1.25) +
 # geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Moisture", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(h)") +
  coord_cartesian(ylim=c(0,6), xlim=c(1.6,4.1))+
  scale_x_continuous(breaks = c(1.6, 2.8, 4.0),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  #annotate("text", x = 1.58, y = 6, label = expression(italic(R^2*m) == 0.15 ~ ";" ~ italic(R^2*c) == 0.69), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) > "0.05"), x=1.58, y=6, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Moist


########################################################################Fe3
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Fe3)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:Fe3,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
fe3_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Fe3),
    MaxpH = max(Fe3)
  )

# new data
new_data_list <- lapply(1:nrow(fe3_ranges), function(i) {
  expand.grid(
    Fe3 = seq(from = fe3_ranges$MinpH[i], to = fe3_ranges$MaxpH[i], length.out = 100),
    Ecotype = fe3_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

ni_Fe3 <- 
  ggplot(new_data, aes(x = Fe3, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  #geom_line(size = 1.25) +
  #geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  #geom_line(data = ALLeff, aes(x = Fe3, y = fit), color = "#ef1828", size = 1) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Fe(III)", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(i)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 3.5))+
  scale_x_continuous(breaks = c(0, 1.6, 3.2),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  #annotate("text", x = 0, y = 6, label = expression(italic(R^2*m) == 0.09 ~ ";" ~ italic(R^2*c) == 0.90), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) > "0.05"), x=0, y=6, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Fe3


##############################################################Fe(II)
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Fe2)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:Fe2,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
fe2_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Fe2),
    MaxpH = max(Fe2)
  )

# new data
new_data_list <- lapply(1:nrow(fe2_ranges), function(i) {
  expand.grid(
    Fe2 = seq(from = fe2_ranges$MinpH[i], to = fe2_ranges$MaxpH[i], length.out = 100),
    Ecotype = fe2_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit


# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}


significant_ecotypes <- c("Tidal zone")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)

ni_Fe2 <- 
  ggplot(new_data, aes(x = Fe2, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Fe(II)", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(k)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 2.4))+
  scale_x_continuous(breaks = c(0, 1.2, 2.4),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.05, y = 6, label = expression(italic(R^2*m) == 0.39 ~ ";" ~ italic(R^2*c) == 0.83), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p) < "0.001"), x=-0.05, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Fe2







######################################################################  Nitrite_AOM Salinity
multi <- dplyr::select(model_data, reference, Nitrite_AOM, Ecotype,Long, Lati, Sali)
multi <- na.omit(multi)
multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))

#��鷽��������
bartlett.test(Nitrite_AOM ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # �������������ȷ�����ظ���
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(Nitrite_AOM~Ecotype:Sali,
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="REML")
summary(mt)
anova(mt)
r.squaredGLMM(mt)


# group and predict
sali_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    MinpH = min(Sali),
    MaxpH = max(Sali)
  )

# new data
new_data_list <- lapply(1:nrow(sali_ranges), function(i) {
  expand.grid(
    Sali = seq(from = sali_ranges$MinpH[i], to = sali_ranges$MaxpH[i], length.out = 100),
    Ecotype = sali_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit



# ggplot
colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # ȥ����Ҫ��դ��
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

significant_ecotypes <- c("Paddy", "Estuary")

# ���˳�������Ecotypeˮƽ������
significant_data <- new_data %>%
  filter(Ecotype %in% significant_ecotypes)


ni_Sali <- 
  ggplot(new_data, aes(x = Sali, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = Nitrite_AOM, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(data = significant_data, size = 1.25) +
  geom_ribbon(data = significant_data, aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = "Salinity", y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), tag = "(m)") +
  coord_cartesian(ylim=c(0,6), xlim=c(0, 3.4))+
  scale_x_continuous(breaks = c(0, 1.6, 3.2),labels = label_number(accuracy = 0.1))+   
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  #annotate("text", label="Dry~Wet: ***; Dry~Tra: ***", x=3.0, y=6, size = 3, hjust = 0) +
  annotate("text", x = -0.05, y = 6, label = expression(italic(R^2*m) == 0.10 ~ ";" ~ italic(R^2*c) == 0.61), size = 4, hjust = 0) +
  annotate("text", label= expression(italic(p)  < "0.05"), x=-0.05, y=5.2, size = 4, hjust = 0) +
  theme_J()+
  theme(legend.position = "none",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0.02, 0.98),
        plot.margin = unit(c(5.5,16.5,5.5,5.5), "pt"))   
ni_Sali




# ����һ��ͨ�õ����⣬�������������
theme_hide_y <- theme(axis.title.y = element_blank(),
                      axis.text.y = element_blank(),
                      plot.tag.position = c(-0.08, 0.98), "pt")

na_Fe21 <- na_Fe2 + theme_hide_y
na_Fe31 <- na_Fe3 + theme_hide_y
#na_TOC1 <- na_TOC + theme_hide_y
na_Sali1  <- na_Sali + theme_hide_y
na_Mnit1 <- na_Mnit + theme_hide_y



ni_Fe21 <- ni_Fe2 + theme_hide_y
ni_Fe31 <- ni_Fe3 + theme_hide_y
#na_TOC1 <- na_TOC + theme_hide_y
ni_Sali1  <- ni_Sali + theme_hide_y
ni_Moxy1 <- ni_Moxy + theme_hide_y



Figure3S <- na_Moist +  na_Fe31 + na_Fe21 + na_TOC + na_Sali1 +  na_Mnit1 +
          ni_Moist +  ni_Fe31 + ni_Fe21 + ni_TOC + ni_Sali1  + ni_Moxy1 +
           plot_layout(ncol=3,nrow=4,guides = 'collect')
  

ggsave("Figure3S.pdf", Figure3S, device="pdf", scale=1, width=180, height=300, units="mm",dpi=300)
