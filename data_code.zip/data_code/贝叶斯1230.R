library(nlme)
library(piecewiseSEM)
library(performance)
library(dplyr)
library(brms)
library(spdep)
library(readr)
library(car)
library(MuMIn)

model_data0 <- read_csv("data.csv")

model_data0 <- model_data0 %>% mutate(
  Nitrate_AOM = as.numeric(Nitrate_AOM),
  id = as.character(id),
  Nitrite_AOM = as.numeric(Nitrite_AOM),
  reference= as.character(reference),
  Ecotype = as.character(Ecotype),
  Long = as.numeric(Long),
  Lati = as.numeric(Lati),
  Tem = as.numeric(Tem),
  MMP = as.numeric(MMP),
  Depth = as.numeric(Depth),
  pH = as.numeric(pH),
  Nitra = as.numeric(Nitra),
  Nitri = as.numeric(Nitri),
  Amm = as.numeric(Amm),
  mcrA = as.numeric(mcrA),
  mcrA = as.numeric(mcrA),
  Moist = as.numeric(Moist),
  Sali = as.numeric(Sali),
  ORP = as.numeric(ORP),
  Meth = as.numeric(Meth),
  Fe3 = as.numeric(Fe3),
  Fe2 = as.numeric(Fe2),
  Sulf = as.numeric(Sulf),
  TOC = as.numeric(TOC),
  TN = as.numeric(TN),
  Moxy = as.numeric(Moxy),
  Mnit = as.numeric(Mnit)
  )

#log
model_data <- mutate(model_data0,Nitrate_AOM = log(Nitrate_AOM+1), Nitrite_AOM = log(Nitrite_AOM+1), Tem=log(Tem+10), 
                     MMP=log(MMP+1), Depth=log(Depth+1),  pH=log(pH+1), Nitra = log(Nitra+1), Nitri = log(Nitri+1), 
                     Amm = log(Amm+1), mcrA = log(mcrA+1), pmoA = log(pmoA+1), Moist = log(Moist+1), 
                     TOC = log(TOC+1), Moxy = log(Moxy+1), Mnit = log(Mnit+1))


BY_na <- dplyr::select(model_data , id, reference, Long, Lati, Nitrate_AOM, Ecotype, TOC,
                      MMP, Tem, Depth, pH, Nitra, Nitri, mcrA, pmoA)
BY_na <- na.omit(BY_na)

#去中心化标准化
BY_na <- BY_na %>%
  mutate(across(.cols = where(is.numeric) & !all_of(c("Long", "Lati")), ~ scale(.) %>% as.vector))


#方差异质性
bartlett.test(Nitrate_AOM ~ Ecotype, data = BY_na)


#考虑空间自相关
set.seed(123) 
BY_na$Lati <- BY_na$Lati + runif(nrow(BY_na), min=-1e-5, max=1e-5)
BY_na$Long <- BY_na$Long + runif(nrow(BY_na), min=-1e-5, max=1e-5)


######全模型

model1 <- lme(Nitrate_AOM ~ Ecotype + Tem + MMP + pH + TOC + Depth + Nitra + mcrA + Nitri + pmoA,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model2 <- lme(TOC ~ Ecotype + Tem + MMP + Depth + pH,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model3 <- lme(Nitra ~ Ecotype + Tem + MMP + TOC + pH + Depth,
              random = ~ 1 | reference,
             # weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model4 <- lme(Nitri ~ Ecotype + Tem + MMP + TOC + pH + Depth + Nitra + mcrA,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model5 <- lme(mcrA ~ Ecotype + Tem + MMP + TOC + pH + Depth + Nitra,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model6 <- lme(pmoA ~ Ecotype + Tem + MMP + TOC + pH + Depth + Nitri,
              random = ~ 1 | reference,
              weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

SEM_na <- psem(model1, model2, model3, model4, model5, model6)

SEM_na <- psem(
  model1,
  model2,
  model3,
  model4,
  model5,
  model6,
  Nitra %~~% Nitri, # 指定潜在变量之间的相关性
  mcrA %~~% pmoA   # 指定因果关系
)

########模型优化
AIC(SEM_na)
dSep(SEM_na) 
summary(SEM_na)
fisherC(SEM_na)


######精简后模型

model1 <- lme(Nitrate_AOM ~ Ecotype + Tem + MMP + TOC + mcrA + pmoA,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model2 <- lme(TOC ~ Ecotype + Tem + MMP + Depth + pH,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model3 <- lme(Nitra ~  Tem + MMP + pH + Depth,
              random = ~ 1 | reference,
              # weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model4 <- lme(Nitri ~ Tem + pH + Nitra + pmoA,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model5 <- lme(mcrA ~ Ecotype + Tem + pH + Depth + Nitra,
              random = ~ 1 | reference,
              #weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

model6 <- lme(pmoA ~  Depth,
              random = ~ 1 | reference,
              weights = varIdent(form =~ 1 | Ecotype),
              # correlation = corExp(form = ~ Lati + Long|reference),
              data = BY_na,
              method = "ML")

SEM_na <- psem(model1, model2, model3, model4, model5, model6)

SEM_na <- psem(
  model1,
  model2,
  model3,
  model4,
  model5,
  model6,
  
  mcrA %~~% pmoA   # 指定相关关系
)

########模型优化
AIC(SEM_na)
dSep(SEM_na) 
summary(SEM_na)
fisherC(SEM_na)



#Model  
bf1 <- bf(Nitrate_AOM ~ 0 + Ecotype + Tem + MMP + TOC + mcrA + pmoA +  (1 | reference)+  gp(Long, Lati))
bf2 <- bf(TOC ~ 0 + Ecotype + Tem + MMP + Depth + pH +  (1 | reference)+  gp(Long, Lati))
bf3 <- bf(Nitra ~ Tem + MMP + pH + Depth + (1 | reference)+  gp(Long, Lati))
bf4 <- bf(Nitri ~ Tem + pH + Nitra + pmoA + (1 | reference)+  gp(Long, Lati))
bf5 <- bf(mcrA ~ 0 +  Ecotype +  Tem + pH + Depth + Nitra  + (1 | reference)+  gp(Long, Lati))
bf6 <- bf(pmoA ~ Depth  + (1 | reference)+  gp(Long, Lati))

BYSEM_na <- brm(bf1 + bf2 + bf3 + bf4 + bf5 + bf6 + set_rescor(TRUE),   #启用残差相关性
                control = list(adapt_delta = 0.9, max_treedepth = 12),
                iter = 10000,data = BY_na)



summary(BYSEM_na)
r2(BYSEM_na)

AIC(BYSEM_na)
plot(BYSEM_na)
fisherC(BYSEM_na)
emmeans(BYSEM_na, pairwise~ Ecotype, data = BY_na)

saveRDS(BYSEM_na, file = "BYSEM_na_0101.rds")

BYSEM_na0 <- readRDS("BYSEM_na_0101.rds")

WAIC(BYSEM_na0, BYSEM_na)

loo(BYSEM_na0, BYSEM_na)

############################Nitrite_AOM
############################Nitrite_AOM
############################Nitrite_AOM

BY_ni <- dplyr::select(model_data , id, reference, Long, Lati, Nitrite_AOM, 
                       Ecotype, MMP, TOC, Tem, Depth, pH, Nitri, pmoA)
BY_ni <- na.omit(BY_ni)

BY_ni<- BY_ni %>%
  mutate(across(.cols = where(is.numeric) & !all_of(c("Long", "Lati")), ~ scale(.) %>% as.vector))


#方差异质性
bartlett.test(Nitrite_AOM ~ Ecotype, data = BY_ni)


#考虑空间自相关
set.seed(123) 
BY_na$Lati <- BY_na$Lati + runif(nrow(BY_na), min=-1e-5, max=1e-5)
BY_na$Long <- BY_na$Long + runif(nrow(BY_na), min=-1e-5, max=1e-5)



#SEM全模型
SEM_ni<-psem(
  lme(Nitrite_AOM ~ Ecotype + Tem + MMP + pH + TOC + Depth + Nitri + pmoA,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(TOC ~ Ecotype + Tem + MMP + Depth + pH,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(Nitri ~ Ecotype + Tem + MMP +  TOC +  pH + Depth,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(pmoA ~ Ecotype + Tem + MMP +  TOC +  pH + Depth + Nitri,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML")
)


AIC(SEM_ni)
dSep(SEM_ni) 
summary(SEM_ni)
fisherC(SEM_ni)




#SEM精简后模型
SEM_ni<-psem(
  lme(Nitrite_AOM ~ Ecotype + Tem + TOC + Depth + Nitri + pmoA,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(TOC ~ Ecotype + Tem + MMP + Depth + pH,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(Nitri ~ Ecotype + Tem + MMP +  TOC + Depth,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML"),
  lme(pmoA ~ Ecotype + pH + Depth,
      random = ~ 1 | reference,
      weights=varIdent(form =~ 1|Ecotype),
      data = BY_ni,
      method="ML")
)



AIC(SEM_ni)
dSep(SEM_ni) 
summary(SEM_ni)
fisherC(SEM_ni)

bf1 <- bf(Nitrite_AOM ~ 0 + Ecotype + Tem + TOC + Depth + Nitri + pmoA + (1 | reference)+  gp(Long, Lati), sigma ~ 0 + Ecotype)
bf2 <- bf(TOC ~ 0 + Ecotype + Tem + MMP + Depth + pH +  (1 | reference)+  gp(Long, Lati), sigma ~ 0 + Ecotype)
bf3 <- bf(Nitri ~ 0 + Ecotype + Tem + MMP +  TOC + Depth + (1 | reference)+  gp(Long, Lati), sigma ~ 0 + Ecotype)
bf4 <- bf(pmoA ~ 0 + Ecotype +pH + Depth + (1 | reference)+  gp(Long, Lati), sigma ~ 0 + Ecotype)


BYSEM_ni <- brm(bf1 + bf2 + bf3 + bf4 + set_rescor(FALSE),
                control = list(adapt_delta = 0.9, max_treedepth = 12),
                iter = 10000,data = BY_ni)

summary(BYSEM_ni)
r2(BYSEM_ni)
fisherC(BYSEM_ni)
plot(BYSEM_ni)
saveRDS(BYSEM_ni, file = "BYSEM_ni_0101.rds")

BYSEM_ni <- readRDS("BYSEM_ni_0101.rds")




####Nitrate-AOM
################直接效应和间接效应
################直接效应和间接效应
################直接效应和间接效应
##加载R包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(reshape2) # Flexibly Reshape Data: A Reboot of the Reshape Package
library(patchwork)



##加载数据（随机编写，无实际意义）
df <- read_csv("SEM_effect_na.csv", col_names = TRUE)

# 选择需要的列
df1 <- dplyr::select(df, sample, group, Direct_effects)
# 将数据整理为绘图所需格式
data <- melt(df1, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("mcrA", "MMT", "Depth", "MMP", "pH", "pmoA","Nitrate", "TOC", "Nitrite"))
                                            
    
data$sample <- factor(data$sample, levels = rev(df1$sample))

#修改标题
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Direct_effects", "Direct effects", value)))
  } else {
    return(as.character(value))
  }
}

# 绘图
Nitrate_AOM_effect1 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.y = element_text(size = 10, color = "black"),
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    axis.title.x = element_text(size = 14, color = "black"),
    legend.position = "none"
  ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(-0.2, 0.7),  # Adjust this for Relative_total_effect
    breaks =c(-0.2,0.0, 0.2, 0.4, 0.6)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c( "#08519C", "#006D2C", "#e04105", "#50B264",  "#C04307", "#2A7AB7", "#ff6600", "#ffa500","#FDAE61"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  )

# 打印图形
Nitrate_AOM_effect1



#间接效应
# 选择需要的列
df2 <- dplyr::select(df, sample, group, Indirect_effects)
# 将数据整理为绘图所需格式
data <- melt(df2, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("mcrA", "MMT", "Depth", "MMP", "pH", "pmoA","Nitrate", "TOC", "Nitrite"))
data$sample <- factor(data$sample, levels = rev(df2$sample))

#修改标题
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Indirect_effects", "Indirect effects", value)))
  } else {
    return(as.character(value))
  }
}


# 绘图
Nitrate_AOM_effect2 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    axis.title.x = element_text(size = 14, color = "black"),
    legend.position = "none"
  ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(-0.2, 0.7),  # Adjust this for Relative_total_effect
    breaks = seq(-0.2, 0.7, by = 0.2)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c( "#08519C", "#006D2C", "#e04105", "#50B264",  "#C04307", "#2A7AB7", "#ff6600", "#ffa500","#FDAE61"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  )

# 打印图形
Nitrate_AOM_effect2




#总效应
# 选择需要的列
df3 <- dplyr::select(df, sample, group, Relative_total_effect)
# 将数据整理为绘图所需格式
data <- melt(df3, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("mcrA", "MMT", "Depth", "MMP", "pH", "pmoA","Nitrate", "TOC", "Nitrite"))
data$sample <- factor(data$sample, levels = rev(df1$sample))
# 绘图
# 自定义labeller函数
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Relative_total_effect", "Total effects (%)", value)))
  } else {
    return(as.character(value))
  }
}

Nitrate_AOM_effect3 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    axis.text.y = element_blank(),  # 隐藏X轴文本
    axis.ticks.y = element_blank(),  # 隐藏X轴刻度
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    legend.position = "right" ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(0, 50),  # Adjust this for Relative_total_effect
    breaks = seq(0, 50, by = 10)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c( "#08519C", "#006D2C", "#e04105", "#50B264",  "#C04307", "#2A7AB7", "#ff6600", "#ffa500","#FDAE61"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  ) 

# 打印图形
Nitrate_AOM_effect3

Nitrate_effect <- Nitrate_AOM_effect1 + Nitrate_AOM_effect2 + Nitrate_AOM_effect3 +
  
  plot_layout(ncol=3,nrow=1,guides = 'collect')

ggsave("Nitrate_effect.pdf", Nitrate_effect, device="pdf", scale=1, width=150, height=80, units="mm",dpi=300)



####Nitrite-AOM
################直接效应和间接效应
################直接效应和间接效应
################直接效应和间接效应
##加载R包
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(reshape2) # Flexibly Reshape Data: A Reboot of the Reshape Package

##加载数据（随机编写，无实际意义）
df <- read_csv("SEM_effect_ni.csv")

# 选择需要的列
df1 <- dplyr::select(df, sample, group, Direct_effects)
# 将数据整理为绘图所需格式
data <- melt(df1, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("pmoA", "Nitrite", "Depth", "TOC", "pH", "MMT", "MMP"))
data$sample <- factor(data$sample, levels = rev(df1$sample))

#修改标题
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Direct_effects", "Direct effects", value)))
  } else {
    return(as.character(value))
  }
}

# 绘图
Nitrite_AOM_effect1 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.y = element_text(size = 10, color = "black"),
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    axis.title.x = element_text(size = 14, color = "black"),
    legend.position = "none"
  ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(-0.2, 0.6),  # Adjust this for Relative_total_effect
    breaks = seq(-0.2, 0.6, by = 0.2)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c("#08519C", "#e04105", "#C04307", "#ff6600", "#ffa500", "#006D2C", "#50B264"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  )

# 打印图形
Nitrite_AOM_effect1



#间接效应
# 选择需要的列
df2 <- dplyr::select(df, sample, group, Indirect_effects)
# 将数据整理为绘图所需格式
data <- melt(df2, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("pmoA", "Nitrite", "Depth", "TOC", "pH", "MMT", "MMP"))
data$sample <- factor(data$sample, levels = rev(df2$sample))

#修改标题
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Indirect_effects", "Indirect effects", value)))
  } else {
    return(as.character(value))
  }
}


# 绘图
Nitrite_AOM_effect2 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    axis.title.x = element_text(size = 14, color = "black"),
    legend.position = "none"
  ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(-0.2, 0.6),  # Adjust this for Relative_total_effect
    breaks = seq(-0.2, 0.6, by = 0.2)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c("#08519C", "#e04105", "#C04307", "#ff6600", "#ffa500", "#006D2C", "#50B264"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  )

# 打印图形
Nitrite_AOM_effect2




#总效应
# 选择需要的列
df3 <- dplyr::select(df, sample, group, Relative_total_effect)
# 将数据整理为绘图所需格式
data <- melt(df3, id.vars = c("sample", "group"))
# 设置 factor levels
data$group <- factor(data$group, levels = c("pmoA", "Nitrite", "Depth", "TOC", "pH", "MMT", "MMP"))
data$sample <- factor(data$sample, levels = rev(df1$sample))
# 绘图
# 自定义labeller函数
custom_labeller <- function(variable, value) {
  # 这里我们假设value就是您要替换的原始标题
  # 我们将其替换为新的标题
  if (variable == "variable") {  # 注意：这里的"variable"是占位符，实际使用时替换为您的列名
    return(as.character(ifelse(value == "Relative_total_effect", "Total effects (%)", value)))
  } else {
    return(as.character(value))
  }
}

Nitrite_AOM_effect3 <- ggplot(data, aes(x = value, y = sample, fill = group)) +
  # 绘制条形图
  geom_col() +
  # 指定分面变量
  facet_grid(~variable, labeller = custom_labeller) +
  # 设置轴标题并去除图例的标题
  labs(fill = NULL, y = NULL, x = NULL) +
  # 主题设置
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 10, color = "black", angle = 270, vjust = 0.5, hjust = 0),
    axis.text.y = element_blank(),  # 隐藏X轴文本
    axis.ticks.y = element_blank(),  # 隐藏X轴刻度
    strip.text = element_text(size = 10, color = "black"),
    legend.text = element_text(size = 12, color = "black"),
    legend.position = "right" ) +
  # 设置x轴的范围
  scale_x_continuous(
    limits = c(0, 30),  # Adjust this for Relative_total_effect
    breaks = seq(0, 30, by = 10)
  ) +
  # 自定义颜色并设置图例的长宽
  scale_fill_manual(
    values = c("#08519C", "#e04105", "#C04307", "#ff6600", "#ffa500", "#006D2C", "#50B264"),
    guide = guide_legend(keywidth = 1.5, keyheight = 1)  # 调整图例大小
  ) 

# 打印图形
Nitrite_AOM_effect3

Nitrite_effect <- Nitrite_AOM_effect1 + Nitrite_AOM_effect2 + Nitrite_AOM_effect3 +
  
  plot_layout(ncol=3,nrow=1,guides = 'collect')

ggsave("Nitrite_effect.pdf", Nitrite_effect, device="pdf", scale=1, width=150, height=65, units="mm",dpi=300)

