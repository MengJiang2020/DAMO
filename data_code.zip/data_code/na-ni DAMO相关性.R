library(MuMIn)
library(effects)
library(cowplot)
library(visreg)
library(glmmTMB)
library(car)
library(nlme)
library(emmeans)
library(ggplot2)
library(scales)
library(dplyr)
library(readr)
library(patchwork)
library(readr)

model_data0 <- read_csv("data.csv")


##na_DAMO_xg1~ni_DAMO_xg1
model_data0 <- model_data0 %>% mutate(
  na_DAMO_xg1 = as.numeric(na_DAMO_xg1),
  ni_DAMO_xg1 = as.numeric(ni_DAMO_xg1),
  reference= as.character(reference),
  Ecotype = as.character(Ecotype),
  Long = as.numeric(Long),
  Lati = as.numeric(Lati)
)

#log
model_data <- mutate(model_data0,na_DAMO_xg1 = log(na_DAMO_xg1+1), ni_DAMO_xg1 = log(ni_DAMO_xg1+1),
                     Long=Long, Lati=Lati)

#data selection
multi <- dplyr::select(model_data, reference, na_DAMO_xg1,ni_DAMO_xg1, Ecotype, Long, Lati)
multi <- na.omit(multi)

#检查方差异质性
bartlett.test(ni_DAMO_xg1 ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # 设置随机种子以确保可重复性
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(ni_DAMO_xg1~ Ecotype:na_DAMO_xg1,  #Ecotype+
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        #correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="ML")
AIC(mt)

summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)



# group and predict
na_DAMO_xg1_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    Minna_DAMO_xg1 = min(na_DAMO_xg1),
    Maxna_DAMO_xg1 = max(na_DAMO_xg1)
  )

# new data
new_data_list <- lapply(1:nrow(na_DAMO_xg1_ranges), function(i) {
  expand.grid(
    na_DAMO_xg1 = seq(from = na_DAMO_xg1_ranges$Minna_DAMO_xg1[i], to = na_DAMO_xg1_ranges$Maxna_DAMO_xg1[i], length.out = 100),
    Ecotype = na_DAMO_xg1_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit

# no Ecotype
global_fit<-lme(ni_DAMO_xg1~ na_DAMO_xg1,
                random = ~1|reference,
                correlation = corExp(form = ~ Lati + Long|reference),
                data=multi,
                method="REML")
summary(global_fit)

ALLeff<-as.data.frame(effects::predictorEffect(predictor="na_DAMO_xg1",mod=global_fit,KR=TRUE,focal.levels=1000))



colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))


# ggplot
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # 去除主要格栅线
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

Rel <- 
  ggplot(new_data, aes(x = na_DAMO_xg1, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = ni_DAMO_xg1, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(size = 1.25) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  geom_line(data = ALLeff, aes(x = na_DAMO_xg1, y = fit), color = "#ef1828", size = 1.5) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(Nitrate-DAMO ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), 
       y = expression(Nitrate/Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})),
       color = "Ecosystems",
       fill = "Ecosystems",
       tag = "(a)") +
  coord_cartesian(ylim=c(-0.5,5.0))+
  coord_cartesian(xlim=c(0,5.0))+
  scale_x_continuous(labels = label_number(accuracy = 0.1)) + 
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  theme_J()+
  theme(legend.position = "right",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(-0.06, 0.98),
        plot.margin = unit(c(5.5,5.5,5.5,15), "pt"))   
Rel



##na_DAMO_xg1~ni_DAMO_xg1
model_data0 <- model_data0 %>% mutate(
  na_DAMO_xg1 = as.numeric(na_DAMO_xg1),
  ni_DAMO_xg1 = as.numeric(ni_DAMO_xg1),
  reference= as.character(reference),
  Ecotype = as.character(Ecotype),
  Long = as.numeric(Long),
  Lati = as.numeric(Lati)
)

#log
model_data <- mutate(model_data0,na_DAMO_xg1 = log(na_DAMO_xg1+1), ni_DAMO_xg1 = log(ni_DAMO_xg1+1),
                     Long=Long, Lati=Lati)

#data selection
multi <- dplyr::select(model_data, reference, na_DAMO_xg1,ni_DAMO_xg1, Ecotype, Long, Lati)
multi <- na.omit(multi)

#检查方差异质性
bartlett.test(ni_DAMO_xg1 ~ Ecotype, data = multi) 

#spatial autocorrelation
set.seed(123)  # 设置随机种子以确保可重复性
multi$Lati <- multi$Lati + runif(nrow(multi), min=-1e-5, max=1e-5)
multi$Long <- multi$Long + runif(nrow(multi), min=-1e-5, max=1e-5)

mt<-lme(ni_DAMO_xg1~ Ecotype:na_DAMO_xg1,  #Ecotype+
        random = ~1|reference,
        weights=varIdent(form =~ 1|Ecotype),
        #correlation = corExp(form = ~ Lati + Long|reference),
        data=multi,
        method="ML")
AIC(mt)

summary(mt)
anova(mt)
emmeans(mt, pairwise~ Ecotype, data = multi)
r.squaredGLMM(mt)


# group and predict
na_DAMO_xg1_ranges <- multi %>%
  group_by(Ecotype) %>%
  summarize(
    Minna_DAMO_xg1 = min(na_DAMO_xg1),
    Maxna_DAMO_xg1 = max(na_DAMO_xg1)
  )

# new data
new_data_list <- lapply(1:nrow(na_DAMO_xg1_ranges), function(i) {
  expand.grid(
    na_DAMO_xg1 = seq(from = na_DAMO_xg1_ranges$Minna_DAMO_xg1[i], to = na_DAMO_xg1_ranges$Maxna_DAMO_xg1[i], length.out = 100),
    Ecotype = na_DAMO_xg1_ranges$Ecotype[i]
  )
})


new_data <- do.call(rbind, new_data_list)

#predict
preds <- predict(mt, newdata = new_data, level = 0, se.fit = TRUE)
new_data$predicted <- preds$fit
new_data$conf.low <- new_data$predicted - 1.96 * preds$se.fit
new_data$conf.high <- new_data$predicted + 1.96 * preds$se.fit

# no Ecotype
global_fit<-lme(ni_DAMO_xg1~ na_DAMO_xg1,
                random = ~1|reference,
                correlation = corExp(form = ~ Lati + Long|reference),
                data=multi,
                method="REML")
summary(global_fit)

ALLeff<-as.data.frame(effects::predictorEffect(predictor="na_DAMO_xg1",mod=global_fit,KR=TRUE,focal.levels=1000))



colors <- c("Paddy" = "#FF7F00", "Tidal zone" = "#08519C", "Inland wetland" = "#00bdcd", "Estuary" = "#8859A8",
            "Forest & Grassland" = "#006D2C")

multi$Ecotype <- factor(multi$Ecotype, levels = c("Paddy", "Tidal zone", "Inland wetland", "Estuary", "Forest & Grassland"))


# ggplot
theme_J <- function(){
  theme_bw() +
    theme(axis.title = element_text(size = 12),
          axis.text = element_text(size = 10, color = "black"),
          legend.title = element_text(size=12),
          legend.text = element_text(size=10),
          strip.text = element_text(size=12),
          panel.grid.major = element_blank(),  # 去除主要格栅线
          panel.grid.minor = element_blank(),
          strip.background = element_blank())
}

Rel <- 
  ggplot(new_data, aes(x = na_DAMO_xg1, y = predicted, color = Ecotype)) +
  geom_point(data = multi, aes(y = ni_DAMO_xg1, color = Ecotype), size = 2, alpha = 0.6) +
  geom_line(size = 1.25) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high, fill = Ecotype), alpha = 0.2, color = NA) +
  geom_line(data = ALLeff, aes(x = na_DAMO_xg1, y = fit), color = "#ef1828", size = 1.5) +
  scale_color_manual(values = colors) +   
  scale_fill_manual(values = colors) +    
  labs(x = expression(Nitrate/Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})), 
       y = expression(Nitrite-AOM ~ "\n" ~ (ln ~ CO[2] ~ g^{-1} ~ day^{-1})),
       color = "Ecosystems",
       fill = "Ecosystems") +
  
  scale_x_continuous(labels = label_number(accuracy = 0.1)) + 
  scale_y_continuous(labels = label_number(accuracy = 0.1)) +   
  theme_J()+
  theme(legend.position = "right",strip.background.x = element_blank(),
        strip.text.x = element_text(size=11,face="bold"),
        plot.tag.position = c(0, 0.98),
        plot.margin = unit(c(5.5,5.5,5.5,5.5), "pt"))   
Rel


ggsave("Figure3SS.pdf", Rel, device="pdf", scale=1, width=200, height=110, units="mm",dpi=500)
